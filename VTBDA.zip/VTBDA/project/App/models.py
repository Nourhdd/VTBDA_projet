from django.db import models

class SavedArticle(models.Model):
    title = models.CharField(max_length=500)
    link = models.URLField(unique=True)
    content = models.TextField(default="No content available.")
    summary = models.TextField(default="No content available.")

   

    def __str__(self):
        return self.title


class DeletedArticle(models.Model):
    title = models.CharField(max_length=500)
    link = models.URLField(unique=True)

    def __str__(self):
        return self.title
