import requests
import xml.etree.ElementTree as ET
from datetime import datetime
from django.shortcuts import render
from django.http import JsonResponse
from .forms import ArxivSearchForm,ScholarSearchForm,ScholarsemSearchForm
from .models import SavedArticle, DeletedArticle
from scholarly import scholarly

def fetch_arxiv_articles(request):
    articles = []  # Liste pour stocker les articles
    form = ArxivSearchForm(request.GET or None)  # Initialiser le formulaire

    if form.is_valid():
        # Récupérer les données du formulaire
        mot_cle = form.cleaned_data['mot_cle']
        date_debut = form.cleaned_data['date_debut']
        date_fin = form.cleaned_data['date_fin']

        # URL de requête de l'API ArXiv
        url = f"http://export.arxiv.org/api/query?search_query=all:{mot_cle}&start=0&max_results=10"
        response = requests.get(url)

        if response.status_code == 200:
            # Parse XML
            root = ET.fromstring(response.content)

            # Parcourir les articles
            for entry in root.findall("{http://www.w3.org/2005/Atom}entry"):
                title = entry.find("{http://www.w3.org/2005/Atom}title").text
                summary = entry.find("{http://www.w3.org/2005/Atom}summary").text
                authors = [author.find("{http://www.w3.org/2005/Atom}name").text for author in entry.findall("{http://www.w3.org/2005/Atom}author")]
                link = entry.find("{http://www.w3.org/2005/Atom}link[@rel='alternate']").attrib['href']

                # Récupérer la date de publication et la convertir
                published = entry.find("{http://www.w3.org/2005/Atom}published").text
                pub_date = datetime.strptime(published, "%Y-%m-%dT%H:%M:%S%z").date()

                # Vérifier si l'article est dans les tables SavedArticle ou DeletedArticle
                if not DeletedArticle.objects.filter(link=link).exists():  # Exclure les articles supprimés
                    is_saved = SavedArticle.objects.filter(link=link).exists()
                    if date_debut <= pub_date <= date_fin:
                        articles.append({
                            'title': title,
                            'summary': summary,
                            'authors': authors,
                            'link': link,
                            'published': pub_date,
                            'is_saved': is_saved
                        })
        else:
            return render(request, 'error.html', {'error_message': f"Erreur lors de la requête. Statut : {response.status_code}"})

    return render(request, 'articles.html', {'form': form, 'articles': articles})


def save_article(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        link = request.POST.get('link')
        

        # Sauvegarder dans la base de données
        SavedArticle.objects.get_or_create(
            title=title,
            link=link,
           
        )

        return JsonResponse({'message': 'Article saved successfully!'})
    return JsonResponse({'message': 'Invalid request'}, status=400)


def delete_article(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        link = request.POST.get('link')

        # Sauvegarder dans la table des articles supprimés
        DeletedArticle.objects.get_or_create(title=title, link=link)

        return JsonResponse({'message': 'Article deleted successfully!'})
    return JsonResponse({'message': 'Invalid request'}, status=400)


"""
# Fonction de vue pour récupérer les articles de Google Scholar
# Fonction de vue pour récupérer les articles de Google Scholar
from scholarly import scholarly
from datetime import datetime

def fetch_scholar_articles(request):
    articles = []  # Liste pour stocker les articles
    form = ScholarSearchForm(request.GET or None)  # Initialiser le formulaire

    if form.is_valid():
        # Récupérer les données du formulaire
        mot_cle = form.cleaned_data['mot_cle']
        date_debut = form.cleaned_data['date_debut']
        date_fin = form.cleaned_data['date_fin']

        # Utiliser scholarly pour récupérer les articles
        search_query = scholarly.search_pubs(mot_cle)
        
        # Limiter le nombre d'articles à 10
        max_articles = 10
        article_count = 0

        for pub in search_query:
            # Récupérer le titre et le lien de l'article
            title = pub.get('bib', {}).get('title', 'No title')
            link = pub.get('pub_url', 'No link available')

            # Récupérer la date de publication et la convertir
            published = pub.get('bib', {}).get('pub_year', 'No date')
            try:
                pub_date = datetime.strptime(published, "%Y").date()
            except ValueError:
                pub_date = None

            # Filtrer les articles par date
            if pub_date and date_debut <= pub_date <= date_fin:
                articles.append({
                    'title': title,
                    'link': link,
                })
                article_count += 1

                # Arrêter après avoir récupéré 10 articles
                if article_count >= max_articles:
                    break

        # Ajouter un message si aucun article n'est trouvé
        if not articles:
            articles.append({
                'title': 'Aucun article trouvé',
                'link': '',
            })

    return render(request, 'article2.html', {'form': form, 'article2': articles})



"""


def fetch_semantic_scholar_articles(request):
    articles = []  # Liste pour stocker les articles
    form = ScholarsemSearchForm(request.GET or None)  # Initialiser le formulaire

    if form.is_valid():
        # Récupérer le mot-clé du formulaire
        mot_cle = form.cleaned_data['mot_cle']

        # URL de l'API Semantic Scholar
        url = "https://api.semanticscholar.org/graph/v1/paper/search"
        params = {
            'query': mot_cle,  # Rechercher les articles par mot-clé
            'limit': 10,  # Limiter les résultats à 10
            'fields': 'title,abstract,paperId,publicationDate',  # Ajouter le champ publicationDate
        }

        response = requests.get(url, params=params)

        if response.status_code == 200:
            data = response.json()
            for paper in data['data']:
                title = paper.get('title', 'No title available')  # Obtenir le titre
                abstract = paper.get('abstract', 'No abstract available')  # Obtenir l'abstract
                publication_date = paper.get('publicationDate', 'Unknown date')  # Obtenir la date de publication
                link = f"https://www.semanticscholar.org/paper/{paper['paperId']}"

                # Exclure les articles supprimés
                if DeletedArticle.objects.filter(link=link).exists():
                    continue

                # Vérifier si l'article est sauvegardé
                is_saved = SavedArticle.objects.filter(link=link).exists()

                # Ajouter l'article à la liste
                articles.append({
                    'title': title,
                    'abstract': abstract,
                    'publication_date': publication_date,
                    'link': link,
                    'is_saved': is_saved
                })

    return render(request, 'article3.html', {'form': form, 'article3': articles})

