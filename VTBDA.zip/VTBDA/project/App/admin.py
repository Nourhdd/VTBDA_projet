from django.contrib import admin
from .models import SavedArticle, DeletedArticle

@admin.register(SavedArticle)
class SavedArticleAdmin(admin.ModelAdmin):
    list_display = ('title', 'link')
    search_fields = ('title', 'link')

@admin.register(DeletedArticle)
class DeletedArticleAdmin(admin.ModelAdmin):
    list_display = ('title', 'link')
    search_fields = ('title', 'link')
