from django.urls import path
from . import views

urlpatterns = [
    path('articles/', views.fetch_arxiv_articles, name='fetch_arxiv_articles'),
    path('article3/', views.fetch_semantic_scholar_articles, name='search_articles'),
    path('save_article/', views.save_article, name='save_article'),
    path('delete_article/', views.delete_article, name='delete_article'),
    
]
